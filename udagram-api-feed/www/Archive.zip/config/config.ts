export const config = {
  'username': "postgres",
  'password': "9855650316",
  'database': "postgres",
  'host': "rdsdb.cbpr5hqtyguu.us-east-1.rds.amazonaws.com",
  'dialect': 'postgres',
  'aws_region': "us-east-1",
  'aws_profile': "myAdmin",
  'aws_media_bucket': "udagram-dev-project",
  'url': "http://localhost:8100",
  'jwt': {
    'secret': "testing",
  },
};
